Hello Citizens! Welcome to the 'VRse!

This small script is simple to use. Simply double click the SCVR-EAC-Bypass.exe and choose the drive that your Star Citizen files are installed on the drop down. 

First of all, you will need to run the SCVR-EAC-Bypass.exe as administrator, so right click the exe and choose 'Run as Administrator' in the popup box. The program checks the hosts file for the changes needed. If it needs the lines added to the hosts file, it does it or will move on if the hosts file looks okay. 

The program also runs a quick look at the hard drives present on your machine and adds them to the drop down. 

It also quickly checks if you have LIVE, PTU, EPTU and/or TECH-PREVIEW files installed and will update the settings.json in each directory that is present.  

If you have any questions, you can ping me on the discord servers of SilvanVR  or Chachi_Sanchez. 

Currently this program only updates the hosts file (if needed) and also changes the settings.json in the EasyAntiCheat folders that exist in your installation. You will need to run the program each time you update files. I will let people know when updated versions are finished. 

There will be another version coming that I'm hoping will give you an easy way to update the 'attributes.xml' file which will include a pulldown to  also choose the VR Headset you are using and it will update the fields (FOV, Width, Height)  making it a one stop way to quickly and easily update your headset settings!  STAY TUNED!




SilvanVR is a CIG employee and VR enthusiast who has stated he will be adding VR in natively to Star Citizen once Vulkan has been fully implemented into the games. It is the VRCitizens sincere hope that we get that functionality soon. You can find him on YouTube and Twitch:
Links:
https://www.twitch.tv/silvanvr
https://www.youtube.com/@silvanvr
Silvan VR Discord: https://discord.gg/smeEq8zyHV

Chachi Sanchez is another VR enthusiast that has spearheaded the work with VorpX to get as many VR Headsets working in Star Citizen as possible. 
Links:
https://www.twitch.tv/chachi_sanchez
https://www.youtube.com/@Chachi_Sanchez
The VRse Discord: https://discord.gg/g2jn2vzju3   


Thanks to them both!
And I thank you, the VRCitizens for downloading this. 

Humbly, 

Chris/Kaglaaz